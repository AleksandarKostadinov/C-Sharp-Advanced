﻿namespace _06.TruckTour
{
    class Pump
    {
        public long Fuel { get; set; }
        public long Distance { get; set; }
    }
}
